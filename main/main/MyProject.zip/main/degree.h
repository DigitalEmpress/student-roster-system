#ifndef DEGREE_H
#define DEGREE_H

//enumerated data type DegreeProgram for the degree programs containing the data type values SECURITY, NETWORK, and SOFTWARE.
enum  DegreeProgram { SECURITY, NETWORK, SOFTWARE };
//string array to hold the string values of the enumerated data type DegreeProgram.
//string array to hold the string values of the enumerated data type DegreeProgram.



#endif // !DEGREE_H
